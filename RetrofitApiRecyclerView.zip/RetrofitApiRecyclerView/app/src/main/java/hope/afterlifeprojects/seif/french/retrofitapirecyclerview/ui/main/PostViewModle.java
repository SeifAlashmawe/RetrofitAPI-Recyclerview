package hope.afterlifeprojects.seif.french.retrofitapirecyclerview.ui.main;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import java.util.List;

import hope.afterlifeprojects.seif.french.retrofitapirecyclerview.pojo.PostModle;

public class PostViewModle extends ViewModel {

    MutableLiveData<List<PostModle>> PostsMutableLiveData = new MutableLiveData<>();

    public void getPosts(){}
}
