package hope.afterlifeprojects.seif.french.retrofitapirecyclerview.ui.main;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import androidx.lifecycle.ViewModelProviders;

import hope.afterlifeprojects.seif.french.retrofitapirecyclerview.R;

public class MainActivity extends AppCompatActivity {

    PostViewModle postViewModle ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        postViewModle = ViewModelProviders.of(this).get(PostViewModle.class);
    }
}
